package shopstack_backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import shopstack_backend.dto.CommissionDTO;
import shopstack_backend.dto.CommissionResponseDTO;
import shopstack_backend.entity.*;
import shopstack_backend.repository.CommissionRepository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Owns all vendor-commission business logic:
 *  - resolving the applicable commission rate (vendor override, else platform default)
 *  - calculating platform commission / vendor payout for an order
 *  - persisting one Commission record per (order, vendor) pair
 *  - keeping those records in sync when order items are cancelled/returned
 *  - exposing read models for the admin dashboard
 */
@Service
public class CommissionService {

    // Platform-wide default commission percentage. Configurable via
    // application.properties (commission.default-rate=12.5, for example)
    // instead of being hard-coded — falls back to 10.0 if not set.
    @Value("${commission.default-rate:10.0}")
    private double defaultCommissionRate;

    @Autowired
    private CommissionRepository commissionRepository;

    public double getDefaultCommissionRate() {
        return defaultCommissionRate;
    }

    /**
     * The rate that actually applies to a vendor: their own override if one
     * has been set by an admin, otherwise the platform default.
     */
    public double resolveRateForVendor(Vendor vendor) {
        if (vendor != null
                && vendor.getCommissionRate() != null
                && vendor.getCommissionRate() >= 0) {
            return vendor.getCommissionRate();
        }
        return defaultCommissionRate;
    }

    /**
     * Calculates and stores commission for an order, split per vendor.
     *
     * Call this:
     *  - right after an order is confirmed (checkout), to create the records
     *  - after any item cancellation/return, to recompute them
     *
     * It is safe to call repeatedly for the same order: existing records for
     * vendors still represented in the order are updated in place; vendors
     * whose items were entirely cancelled have their record zeroed out and
     * marked CANCELLED rather than duplicated.
     */
    @Transactional
    public void syncCommissionsForOrder(Order order) {
        if (order == null || order.getId() == null || order.getItems() == null) {
            return;
        }

        // Sum non-cancelled line totals per vendor for this order
        Map<Long, Vendor> vendorsById = new LinkedHashMap<>();
        Map<Long, BigDecimal> salesByVendorId = new LinkedHashMap<>();

        for (OrderItem item : order.getItems()) {
            if (item.getStatus() == OrderStatus.CANCELLED) {
                continue;
            }
            Product product = item.getProduct();
            if (product == null || product.getVendor() == null) {
                continue; // orphaned/deleted product — nothing to attribute commission to
            }
            Vendor vendor = product.getVendor();
            BigDecimal lineTotal = item.getLineTotal() != null ? item.getLineTotal() : BigDecimal.ZERO;

            vendorsById.put(vendor.getId(), vendor);
            salesByVendorId.merge(vendor.getId(), lineTotal, BigDecimal::add);
        }

        List<Commission> existing = commissionRepository.findByOrder_Id(order.getId());
        Map<Long, Commission> existingByVendorId = existing.stream()
                .collect(Collectors.toMap(c -> c.getVendor().getId(), c -> c));

        // Upsert a commission record for every vendor still represented in the order
        for (Map.Entry<Long, BigDecimal> entry : salesByVendorId.entrySet()) {
            Long vendorId = entry.getKey();
            Vendor vendor = vendorsById.get(vendorId);
            BigDecimal saleAmount = entry.getValue().setScale(2, RoundingMode.HALF_UP);

            Commission commission = existingByVendorId.remove(vendorId);

            // Freeze the rate at whatever it was when this record was first
            // created; only a brand-new record picks up the current rate.
            double rate = (commission != null && commission.getCommissionRate() != null)
                    ? commission.getCommissionRate()
                    : resolveRateForVendor(vendor);

            BigDecimal commissionAmount = saleAmount
                    .multiply(BigDecimal.valueOf(rate))
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
            BigDecimal vendorAmount = saleAmount.subtract(commissionAmount);

            if (commission == null) {
                commission = new Commission();
                commission.setOrder(order);
                commission.setVendor(vendor);
            }
            commission.setSaleAmount(saleAmount);
            commission.setCommissionRate(rate);
            commission.setCommissionAmount(commissionAmount);
            commission.setVendorAmount(vendorAmount);
            if (commission.getStatus() == null || commission.getStatus() == CommissionStatus.CANCELLED) {
                commission.setStatus(CommissionStatus.CONFIRMED);
            }
            commissionRepository.save(commission);
        }

        // Anything left in existingByVendorId belonged to a vendor whose
        // items were all cancelled since the last sync — void it out.
        BigDecimal zero = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        for (Commission leftover : existingByVendorId.values()) {
            leftover.setSaleAmount(zero);
            leftover.setCommissionAmount(zero);
            leftover.setVendorAmount(zero);
            leftover.setStatus(CommissionStatus.CANCELLED);
            commissionRepository.save(leftover);
        }
    }

    @Transactional(readOnly = true)
    public List<CommissionResponseDTO> getAllCommissionRecords() {
        return commissionRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<CommissionResponseDTO> getCommissionRecordsForVendor(Long vendorId) {
        return commissionRepository.findByVendor_IdOrderByCreatedAtDesc(vendorId).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     * Aggregated per-vendor summary (total sales / total commission earned),
     * built from the stored per-order records rather than a live join —
     * cancelled commissions are excluded automatically.
     */
    @Transactional(readOnly = true)
    public List<CommissionDTO> getVendorCommissionSummary() {
        List<Commission> active = commissionRepository.findAll().stream()
                .filter(c -> c.getStatus() != CommissionStatus.CANCELLED)
                .collect(Collectors.toList());

        Map<Long, List<Commission>> byVendor = active.stream()
                .collect(Collectors.groupingBy(c -> c.getVendor().getId()));

        List<CommissionDTO> result = new ArrayList<>();
        for (List<Commission> vendorCommissions : byVendor.values()) {
            Vendor vendor = vendorCommissions.get(0).getVendor();

            BigDecimal totalSales = vendorCommissions.stream()
                    .map(Commission::getSaleAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal totalCommission = vendorCommissions.stream()
                    .map(Commission::getCommissionAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            result.add(new CommissionDTO(
                    vendor.getId(),
                    vendor.getName(),
                    totalSales,
                    resolveRateForVendor(vendor),
                    totalCommission
            ));
        }
        return result;
    }

    @Transactional
    public CommissionResponseDTO updateCommissionStatus(Long commissionId, CommissionStatus newStatus) {
        Commission commission = commissionRepository.findById(commissionId)
                .orElseThrow(() -> new IllegalArgumentException("Commission record not found: " + commissionId));
        commission.setStatus(newStatus);
        return toDto(commissionRepository.save(commission));
    }

    private CommissionResponseDTO toDto(Commission c) {
        CommissionResponseDTO dto = new CommissionResponseDTO();
        dto.setId(c.getId());
        dto.setOrderId(c.getOrder().getId());
        dto.setVendorId(c.getVendor().getId());
        dto.setVendorName(c.getVendor().getName());
        dto.setSaleAmount(c.getSaleAmount());
        dto.setCommissionRate(c.getCommissionRate());
        dto.setCommissionAmount(c.getCommissionAmount());
        dto.setVendorAmount(c.getVendorAmount());
        dto.setStatus(c.getStatus().name());
        dto.setCreatedAt(c.getCreatedAt());
        return dto;
    }
}