import api from './api';

export const getDashboardSummary = async () => {
  const response = await api.get('/admin/dashboard/summary');
  return response.data;
};

export const getAdminVendors = async () => {
  const response = await api.get('/admin/vendors');
  return response.data;
};

export const getAdminOrders = async () => {
  const response = await api.get('/admin/orders');
  return response.data;
};

export const getAdminCommissions = async () => {
  const response = await api.get('/admin/commissions');
  return response.data;
};

// Per-order commission records: Order ID, Vendor, Sale Amount, Rate,
// Commission Amount, Vendor Amount, Status, Date.
export const getAdminCommissionDetails = async () => {
  const response = await api.get('/admin/commissions/details');
  return response.data;
};

// Mark a single commission record as CONFIRMED / PAID / CANCELLED.
export const updateCommissionStatus = async (commissionId, status) => {
  const response = await api.patch(`/admin/commissions/${commissionId}/status`, { status });
  return response.data;
};

// Set (or clear with null) a vendor's commission rate override.
export const updateVendorCommissionRate = async (vendorId, rate) => {
  const response = await api.put(`/admin/vendors/${vendorId}/commission-rate`, { rate });
  return response.data;
};

export const getSystemStatus = async () => {
  const response = await api.get('/admin/system/status');
  return response.data;
};
export const getAdminReport = async () => {
  const response = await api.get('/admin/reports/business');
  return response.data;
};