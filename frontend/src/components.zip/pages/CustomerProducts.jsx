import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllProducts } from "../services/productService";

function CustomerProducts() {

  const navigate = useNavigate();

  const [products, setProducts] = useState([]);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const response = await getAllProducts();
      setProducts(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const getStockStatus = (stock) => {
    if (stock <= 0)
      return (
        <span className="text-red-600 font-semibold">
          Out of Stock
        </span>
      );

    if (stock <= 5)
      return (
        <span className="text-orange-500 font-semibold">
          Low Stock
        </span>
      );

    return (
      <span className="text-green-600 font-semibold">
        In Stock
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-slate-100 p-8">

      <div className="max-w-7xl mx-auto">

        <h1 className="text-4xl font-bold text-blue-600 mb-8">
          Shop Products
        </h1>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

          {products.map((product) => (

            <div
              key={product.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden"
            >

              <img
                src={
                  product.imageUrl ||
                  "https://via.placeholder.com/400x250?text=No+Image"
                }
                alt={product.name}
                className="w-full h-56 object-cover"
              />

              <div className="p-5">

                <h2 className="text-xl font-bold">
                  {product.name}
                </h2>

                <p className="text-gray-500">
                  {product.brand}
                </p>

                <p className="text-sm text-blue-600 mt-1">
                  {product.category?.name}
                </p>

                <p className="mt-3 text-gray-700 line-clamp-2">
                  {product.description}
                </p>

                <div className="mt-4">

                  <p className="text-2xl font-bold text-green-700">
                    ₹{product.price}
                  </p>

                  <p className="mt-2">
                    {getStockStatus(product.stock)}
                  </p>

                </div>

                <div className="mt-5 flex gap-2">

                  <button
                    onClick={() =>
                      navigate(`/product/${product.id}`)
                    }
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg"
                  >
                    View Details
                  </button>

                  <button
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg"
                  >
                    Add to Cart
                  </button>

                </div>

              </div>

            </div>

          ))}

        </div>

      </div>

    </div>
  );
}

export default CustomerProducts;